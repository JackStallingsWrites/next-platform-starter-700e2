SILVER SERAPHIM — thesilverseraphim.com
Five-page site. Her world: moonlight on slate (cool, austere, reverent).
NOT Jack's palette. Thesis: she sees people, so they walk away being seen.

PAGES (5-section nav)
  index.html         Home — rotating hero + Meet Me + gallery doors
  art.html           The Art — hub linking the four galleries
  portraits.html     The Art · Portraits
  relationships.html The Art · Relationships
  concept.html       The Art · Concept Work
  projects.html      The Art · Projects
  experience.html    The Experience — one open page (we talk first, run of show, after)
  about.html         About Silver Seraphim — philosophy / why she shoots
  connect.html       Connect — question-first intake
  styles.css         Her design system (Cormorant Garamond / Lora / Montserrat)
  _redirects, robots.txt, (add sitemap if desired)

NOTE: the threshold/"Deeper" crossing was RETIRED at her direction.
The Experience is now one open, welcoming page — no consent-gate.

═══════════════════════════════════════════════════════════
ADDING IMAGES — the site is built image-ready. Here's where they go:
═══════════════════════════════════════════════════════════
Create an /images folder next to the HTML, then:

1) ROTATING HERO (index.html) — 3 to 5 signature images.
   Find the 3 lines like:  <div class="hero-slide ..." data-empty></div>
   Replace each with:
     <div class="hero-slide is-active" style="background-image:url('images/hero-1.jpg')"></div>
     <div class="hero-slide" style="background-image:url('images/hero-2.jpg')"></div>
     ... (keep is-active on the FIRST one only)
   The dots auto-match the number of slides you keep.

2) MEET ME portrait (index.html) and ABOUT portrait (about.html)
   Find:  <div class="meet-portrait" data-empty> ... </div>
          <div class="about-portrait" data-empty> ... </div>
   Inside each, uncomment / add:  <img src="images/silver-portrait.jpg" alt="Silver Seraphim">
   and remove the  data-empty  attribute on that div.

3) GALLERY CATEGORY TILES (index.html + art.html) — the four doors
   Find each:  <a class="gal-cat" data-empty href="...">
   Add as the FIRST child inside:  <img src="images/cat-portraits.jpg" alt="">
   and remove  data-empty  from that <a>.

4) GALLERY PAGES (portraits/relationships/concept/projects.html)
   Each has a grid of:  <div class="shot" data-empty data-label="..." style="--ar:3/4"></div>
   Replace each with:   <div class="shot"><img src="images/portraits/01.jpg" alt=""></div>
   Add or remove .shot divs to match how many images you have.
   (The --ar values just shape the empty placeholders; real images set their own height.)

Tip: keep images web-sized (long edge ~2000px, compressed) so pages stay fast.

DEPLOY (Netlify drag-and-drop)
  Drag the CONTENTS of this folder (incl. your /images folder) onto Netlify.
  No build step. _redirects + robots.txt picked up automatically.

STILL NEEDS HER
  - The photographs (hero, portraits, galleries) per the guide above.
  - Wire the Connect form to her email/provider (inert by design).
  - Confirm Instagram handle in the footer.

SHIPPED AS PART OF: Studio by Jack — the second client world (after Red & Curly).
